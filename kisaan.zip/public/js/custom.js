
$('.cws_loader_container').delay(1500).fadeOut(300,function(){
						$('body').addClass('loaded');									
});

if ($('.how_do_we_do').length > 0) {
    $('.how_do_we_do').owlCarousel({
        loop: false,
        margin: 20,
        responsiveClass: true,
        items: 3,
        navText: ["<i class='ti ti-angle-left'></i>", "<i class='ti ti-angle-right'></i>"],
        nav: true,
        center: false,
        dots: false,
        responsive: {
            0: {
                items: 1,
                dots: true,
                margin: 0
            },
            600: {
                items: 2,
                dots: true,
                margin: 0
            },
            1000: {
                items: 3,
                dots: true,
                margin: 0
            },
            1300: {
                items: 3,
            },
            1800: {
                items: 4,
            }
        }
    })
}



if ($('.testimonial .owl-carousel').length > 0) {
    $('.testimonial .owl-carousel').owlCarousel({
        loop: false,
        margin: 0,
        responsiveClass: true,
        items: 2,
        navText: ["<i class='ti ti-angle-left'></i>", "<i class='ti ti-angle-right'></i>"],
        nav: false,
        center: false,
        dots: true,
        responsive: {
            0: {
                items: 1,
                dots: true,
                margin: 0
            },
            600: {
                items: 2,
                dots: true,
                margin: 0
            },
            1000: {
                items: 2,
                dots: true,
                margin: 0
            },
            1300: {
                items: 2,
            },
            1800: {
                items: 2,
            }
        }
    })
}




if ($('.videos_slider').length > 0) {
    $('.videos_slider').owlCarousel({
        loop: false,
        margin: 40,
        responsiveClass: true,
        items: 3,
        navText: ["<i class='ti ti-angle-left'></i>", "<i class='ti ti-angle-right'></i>"],
        nav: true,
        center: false,
        dots: false,
        responsive: {
            0: {
                items: 1,
                dots: true,
                margin: 0
            },
            600: {
                items: 2,
                dots: true,
                margin: 0
            },
            1000: {
                items: 3,
                dots: true,
                margin: 0
            },
            1300: {
                items: 3,
            },
            1800: {
                items: 3,
            }
        }
    })
}




/*
$(window).scroll(function() {
    var top = $(this).scrollTop();
    if (top > 50) {
        $('header').addClass('scroll');
    } else {
        $('header').removeClass('scroll');
    }

});

*/



$('.form .input').focus(function(){
	$(this).parent().find('.placeholder').addClass('up');
	$(this).css('border-bottom','1px solid rgba(0,0,0,0.5)');
});

$('.form .input').blur(function(){
	if(!$(this).val()){								
		$(this).parent().find('.placeholder').removeClass('up');
		$(this).css('border-bottom','1px solid rgba(0,0,0,0.1)');
	}
});

$('.form .input').each(function(){
	if(!$(this).val()){								
		$(this).parent().find('.placeholder').removeClass('up');								 
	}
	else{
		$(this).parent().find('.placeholder').addClass('up');	
		$(this).css('border-bottom','1px solid rgba(0,0,0,0.5)');
	}
});


if($('.about_slider').length>0){
	$('.about_slider').owlCarousel({
    loop:true,
	autoplay:true,
    margin:30,
    responsiveClass:true,
	items:1,
	navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
	nav: true,
	dots:true,
	responsive:{
        0:{
            items:1,
            nav:false,
			margin:0,
        },
        600:{
            items:1,
            nav:false,
			margin:0,
        },
        1000:{
            items:1,
            nav:false,
			margin:0,
        },
		 1300:{
            items:1,
        },		
    }
    
})
}




if($('.about_testimonials .owl-carousel').length>0){
	$('.about_testimonials .owl-carousel').owlCarousel({
    loop:true,
	autoplay:true,
    margin:0,
    responsiveClass:true,
	items:1,
	navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
	nav: false,
	dots:true,
	responsive:{
        0:{
            items:1,
            nav:false,
			margin:0,
        },
        600:{
            items:1,
            nav:false,
			margin:0,
        },
        1000:{
            items:1,
            nav:false,
			margin:0,
        },
		 1300:{
            items:1,
        },		
    }
    
})
}




if ($('.about_slider2').length > 0) {
    $('.about_slider2').owlCarousel({
		autoplay:true,							
        loop: true,
        margin: 20,
        responsiveClass: true,
        items: 1,
        navText: ["<i class='ti ti-angle-left'></i>", "<i class='ti ti-angle-right'></i>"],
        nav: false,
        center: false,
        dots: true,
        responsive: {
            0: {
                items: 1,
                dots: true,
                margin: 0
            },
            600: {
                items: 1,
                dots: true,
                margin: 0
            },
            1000: {
                items: 1,
                dots: true,
                margin: 0
            },
            1300: {
                items: 1,
            },
            1800: {
                items: 1,
            }
        }
    })
}




if($('.store .owl-carousel').length>0){
	$('.store .owl-carousel').owlCarousel({
    loop:true,
	autoplay:true,
    margin:20,
    responsiveClass:true,
	items:4,
	navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
	nav: true,
	dots:false,
	responsive:{
        0:{
            items:1,
            nav:false,
			margin:0,
        },
        600:{
            items:2,
            nav:false,
			margin:0,
        },
        1000:{
            items:3,
            nav:false,
			margin:0,
        },
		 1300:{
            items:3,
        },		
    }
    
})
}


if($('.looks .owl-carousel').length>0){
	$('.looks .owl-carousel').owlCarousel({
    loop:true,
	autoplay:true,
    margin:20,
    responsiveClass:true,
	items:4,
	navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
	nav: true,
	dots:false,
	responsive:{
        0:{
            items:1,
            nav:false,
			margin:0,
        },
        600:{
            items:2,
            nav:false,
			margin:0,
        },
        1000:{
            items:4,
            nav:false,
			margin:0,
        },
		 1300:{
            items:4,
        },		
    }
    
})
}



$('.fixed_nav .menu li a').click(function(){
		$(this).parent().find('.drop').addClass('open');								  	
});

$('.fixed_nav .back').click(function(){
	$(this).parent().removeClass('open');									 
});



$('.open_nav').click(function(){
	$('.overlay').fadeIn(300);						  
	$('.fixed_nav').addClass('open');									 
});


$('.fixed_nav .close').click(function(){
	$('.fixed_nav').removeClass('open');	
	$('.overlay').fadeOut(300);						  								 
});

$('.edit_fName_Lname').click(function(){
	$('.edit_fname_lname').addClass('open');		
});







const buttons = document.querySelectorAll('.btn_step')
const formPages = document.querySelectorAll('.form-page')
const bars = document.querySelectorAll('.bar-circle')   

let pageStates = {
    oldPageNum: null,
    currentPage: null,
}

const pageTransform = () => {
    formPages.forEach(page => {        
        page.style.transform = `translateX(-${(pageStates.currentPage) * 100}%)`
    })
}

const handleClasses = () => {     

    bars.forEach(bar => {
        bar.classList.remove('active')
    })

    if(bars[pageStates.currentPage]) {
        for(let i = 0; i < pageStates.currentPage + 1; i++) {
            bars[i].classList.add('active')
        }
    } else {
        bars.forEach(bar => {
            bar.classList.add('active')
            bar.classList.add('done')
        })
    }
}

const indexFinder = (el) => {    
    let i = 0;
    for(; el = el.previousElementSibling; i++);
    return i;
}

const pageHandler = (e) => {
    e.preventDefault()

    const navData = e.currentTarget.getAttribute('data-nav')
    pageStates.oldPageNum = indexFinder(e.currentTarget.parentElement)
    
    if(navData == "prev") {
        pageStates.currentPage = pageStates.oldPageNum - 1
    }  if(navData == "next")  {
        pageStates.currentPage = pageStates.oldPageNum + 1
    }    

    pageTransform()
    handleClasses()
}


const barHandler = (e) => {
    e.preventDefault()
    pageStates.currentPage = indexFinder(e.currentTarget)

    pageTransform()
    handleClasses()
}

buttons.forEach(button => {
    button.addEventListener('click', pageHandler)
})

bars.forEach(bar => {
    bar.addEventListener('click', barHandler)
})






$('.open_popup').click(function(){
	var modal=$(this).attr('data_modal');
	$('#'+modal).fadeIn(200);
});

$('.modal_custom .modal_popup .close_').click(function(){
	$('.modal_custom').fadeOut(200);
});