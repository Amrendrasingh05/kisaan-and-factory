const newLocal = "https://kisaanandfactory.com/";
// const newLocal = "http://localhost:3002/"

let Data = {
  BaseUrl: newLocal,
  ServerUrl: "https://kisaanandfactory.com/static_file/",
  RAZORPAY_KEY_ID: "rzp_test_88tVxFiNiyplnG",
  RAZORPAY_SECRET: "3v5B8fJI7DASSfOTEU2AXAms",
};
export default Data;
