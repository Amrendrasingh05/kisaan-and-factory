import React from "react";

import Header from "../common/header.component";
import Footer from "../common/homefooter.component";
import ImdateData from "../../images/photo-1628530246501.jpg";

const Dashboard = () => {
  return (
    <>
      <Header />
      <section class="uk-section">
        <div class="uk-container">
          <div data-uk-grid>
            <div class="uk-width-expand@m uk-width-1-1">
              <h2 class="innheader">REFUND POLICY</h2>
              <p>
                All our clients are very important to us, that's why Kisaan
                Factory ("Company"), has created the following Refund Policy to
                let You know how we handle the refunds for the goods ordered and
                bought on our website https://www.kisaanandfactory.com/
                ("Website"). The terms "You," "Your," and "Yours" refer to the
                entity/ person/ organization using our Website. When this Policy
                mentions "we", "us,", and "our" it refers to the Company and its
                subsidiaries or /and affiliates. The term "goods" refers to any
                product or item bought on our Website by You. This Refund Policy
                is governed by our [Terms of
                Services](https://www.kisaanandfactory.com/#website).
              </p>
              <p>
                For any questions regarding this Refund Policy or any requests
                regarding the refunds and returns, please contact us by phone
                01755006831 or other contacts provided in our website. You have
                the right, without giving a reason, to return the goods within
                14 days, if it has not been used, damaged or its appearance has
                not substantially changed, that is, the appearance of the
                product or its packaging has been made only such alterations as
                were necessary to inspect the goods received. The right to
                withdraw from a distance contract within 14 days without giving
                a reason does not apply to legal persons (e.g. companies,
                entrepreneurs). This Return policy does not limit Your statutory
                rights to withdraw or rights You may have in relation to
                incorrect, damaged or defective goods.
              </p>
            </div>
          </div>
          <br></br>
          <h2 class="innheader">Standard Returns</h2>
          <p>
            Any goods that You wish to return must be in the original packaging
            and unopened, in a condition fit for resale. If the Goods to be
            returned do not meet these conditions, we will be unable to offer a
            refund. You must place your refund request within 14 days of
            delivery of the item.
          </p>
          <p>
            Please return the goods to us by sending to the address: Kisaan
            Factory, Urban estate Phase 1, Patiala Punjab, 147002, India In case
            of the return of the goods, you will be responsible for paying the
            return shipping costs.
          </p>
          <p>
            You must exercise return right responsibly and return the product in
            the original neat packaging, as well as return all complete parts of
            the product. You are responsible for the complete set of the
            returned goods. If the goods are not complete, we won't be able to
            accept the returned goods and issue a refund. Once the Goods have
            been received and checked by our staff, a refund will be authorised
            by the same method that the payment was made. Depending on your
            financial institution, refunds can take up to 14 days to be credited
            to your original payment method. In all cases we have the right to
            suspend the refund until the goods are received back and inspected.
            If You fail to meet the deadlines of our Return policy, we will be
            unable to offer a refund.
          </p>

          <br></br>
          <h2 class="innheader">Defective goods</h2>
          <p>
            In certain cases, such as defective, damaged or wrong goods, you may
            be required to provide evidence of the issue, such as a photo or
            video, or to return the item to receive a refund. You must contact
            our company at 01755006831 and return within 14 days upon purchase
            and provide detailed information, such as:
          </p>
          <ul>
            <li>Proof of purchase</li>
          </ul>
          <p>
            When submitting a complaint, You must indicate how You wish the
            claim to be resolved:
          </p>
          <ul>
            <li>To replace the defective goods with quality items</li>
            <li>To supplement the incomplete goods with missing components</li>
            <li>
              To apply a discount to the goods, e.g. reduce the price of the
              goods accordingly
            </li>
            <li> To refund the money paid</li>
            <li> To receive store credit </li>
          </ul>
          <p>
            In case You are required to return the goods back to us, You will be
            responsible for paying the return shipping costs. The goods must be
            returned in the original packaging (with instructions and/or
            warranty card, if they were delivered with the product).
          </p>
          <br></br>
          <h2 class="innheader">Further information</h2>
          <p>
            This Policy applies only to the refunds for the goods and services
            sold by our Company. Our Policy does not apply to the refunds for
            the goods and services offered by other companies or individuals.
          </p>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Dashboard;
